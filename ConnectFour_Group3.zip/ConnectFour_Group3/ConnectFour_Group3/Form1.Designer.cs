﻿namespace ConnectFour_Group3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblTurnDisp = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.box66 = new System.Windows.Forms.PictureBox();
            this.box65 = new System.Windows.Forms.PictureBox();
            this.box67 = new System.Windows.Forms.PictureBox();
            this.box64 = new System.Windows.Forms.PictureBox();
            this.box63 = new System.Windows.Forms.PictureBox();
            this.box62 = new System.Windows.Forms.PictureBox();
            this.box61 = new System.Windows.Forms.PictureBox();
            this.box56 = new System.Windows.Forms.PictureBox();
            this.box55 = new System.Windows.Forms.PictureBox();
            this.box57 = new System.Windows.Forms.PictureBox();
            this.box54 = new System.Windows.Forms.PictureBox();
            this.box53 = new System.Windows.Forms.PictureBox();
            this.box52 = new System.Windows.Forms.PictureBox();
            this.box51 = new System.Windows.Forms.PictureBox();
            this.box46 = new System.Windows.Forms.PictureBox();
            this.box45 = new System.Windows.Forms.PictureBox();
            this.box47 = new System.Windows.Forms.PictureBox();
            this.box44 = new System.Windows.Forms.PictureBox();
            this.box43 = new System.Windows.Forms.PictureBox();
            this.box42 = new System.Windows.Forms.PictureBox();
            this.box41 = new System.Windows.Forms.PictureBox();
            this.box36 = new System.Windows.Forms.PictureBox();
            this.box35 = new System.Windows.Forms.PictureBox();
            this.box37 = new System.Windows.Forms.PictureBox();
            this.box34 = new System.Windows.Forms.PictureBox();
            this.box33 = new System.Windows.Forms.PictureBox();
            this.box32 = new System.Windows.Forms.PictureBox();
            this.box31 = new System.Windows.Forms.PictureBox();
            this.box26 = new System.Windows.Forms.PictureBox();
            this.box25 = new System.Windows.Forms.PictureBox();
            this.box27 = new System.Windows.Forms.PictureBox();
            this.box24 = new System.Windows.Forms.PictureBox();
            this.box23 = new System.Windows.Forms.PictureBox();
            this.box22 = new System.Windows.Forms.PictureBox();
            this.box21 = new System.Windows.Forms.PictureBox();
            this.box16 = new System.Windows.Forms.PictureBox();
            this.box15 = new System.Windows.Forms.PictureBox();
            this.box17 = new System.Windows.Forms.PictureBox();
            this.box14 = new System.Windows.Forms.PictureBox();
            this.box13 = new System.Windows.Forms.PictureBox();
            this.box12 = new System.Windows.Forms.PictureBox();
            this.box11 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.box66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.box11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // lblTurnDisp
            // 
            this.lblTurnDisp.AutoSize = true;
            this.lblTurnDisp.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurnDisp.Location = new System.Drawing.Point(392, 26);
            this.lblTurnDisp.Name = "lblTurnDisp";
            this.lblTurnDisp.Size = new System.Drawing.Size(218, 36);
            this.lblTurnDisp.TabIndex = 54;
            this.lblTurnDisp.Text = "Player 1\'s Turn";
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(65, 12);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(199, 50);
            this.btn_Back.TabIndex = 55;
            this.btn_Back.Text = "Return to Main Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // box66
            // 
            this.box66.Location = new System.Drawing.Point(696, 641);
            this.box66.Name = "box66";
            this.box66.Size = new System.Drawing.Size(124, 111);
            this.box66.TabIndex = 53;
            this.box66.TabStop = false;
            this.box66.Tag = "5";
            this.box66.Click += new System.EventHandler(this.playPiece);
            this.box66.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box66.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box65
            // 
            this.box65.Location = new System.Drawing.Point(572, 641);
            this.box65.Name = "box65";
            this.box65.Size = new System.Drawing.Size(124, 111);
            this.box65.TabIndex = 51;
            this.box65.TabStop = false;
            this.box65.Tag = "4";
            this.box65.Click += new System.EventHandler(this.playPiece);
            this.box65.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box65.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box67
            // 
            this.box67.Location = new System.Drawing.Point(820, 641);
            this.box67.Name = "box67";
            this.box67.Size = new System.Drawing.Size(124, 111);
            this.box67.TabIndex = 52;
            this.box67.TabStop = false;
            this.box67.Tag = "6";
            this.box67.Click += new System.EventHandler(this.playPiece);
            this.box67.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box67.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box64
            // 
            this.box64.Location = new System.Drawing.Point(448, 641);
            this.box64.Name = "box64";
            this.box64.Size = new System.Drawing.Size(124, 111);
            this.box64.TabIndex = 50;
            this.box64.TabStop = false;
            this.box64.Tag = "3";
            this.box64.Click += new System.EventHandler(this.playPiece);
            this.box64.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box64.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box63
            // 
            this.box63.Location = new System.Drawing.Point(324, 641);
            this.box63.Name = "box63";
            this.box63.Size = new System.Drawing.Size(124, 111);
            this.box63.TabIndex = 49;
            this.box63.TabStop = false;
            this.box63.Tag = "2";
            this.box63.Click += new System.EventHandler(this.playPiece);
            this.box63.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box63.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box62
            // 
            this.box62.Location = new System.Drawing.Point(200, 641);
            this.box62.Name = "box62";
            this.box62.Size = new System.Drawing.Size(124, 111);
            this.box62.TabIndex = 48;
            this.box62.TabStop = false;
            this.box62.Tag = "1";
            this.box62.Click += new System.EventHandler(this.playPiece);
            this.box62.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box62.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box61
            // 
            this.box61.Location = new System.Drawing.Point(76, 641);
            this.box61.Name = "box61";
            this.box61.Size = new System.Drawing.Size(124, 111);
            this.box61.TabIndex = 47;
            this.box61.TabStop = false;
            this.box61.Tag = "0";
            this.box61.Click += new System.EventHandler(this.playPiece);
            this.box61.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box61.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box56
            // 
            this.box56.Location = new System.Drawing.Point(696, 530);
            this.box56.Name = "box56";
            this.box56.Size = new System.Drawing.Size(124, 111);
            this.box56.TabIndex = 45;
            this.box56.TabStop = false;
            this.box56.Tag = "5";
            this.box56.Click += new System.EventHandler(this.playPiece);
            this.box56.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box56.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box55
            // 
            this.box55.Location = new System.Drawing.Point(572, 530);
            this.box55.Name = "box55";
            this.box55.Size = new System.Drawing.Size(124, 111);
            this.box55.TabIndex = 43;
            this.box55.TabStop = false;
            this.box55.Tag = "4";
            this.box55.Click += new System.EventHandler(this.playPiece);
            this.box55.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box55.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box57
            // 
            this.box57.Location = new System.Drawing.Point(820, 530);
            this.box57.Name = "box57";
            this.box57.Size = new System.Drawing.Size(124, 111);
            this.box57.TabIndex = 44;
            this.box57.TabStop = false;
            this.box57.Tag = "6";
            this.box57.Click += new System.EventHandler(this.playPiece);
            this.box57.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box57.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box54
            // 
            this.box54.Location = new System.Drawing.Point(448, 530);
            this.box54.Name = "box54";
            this.box54.Size = new System.Drawing.Size(124, 111);
            this.box54.TabIndex = 42;
            this.box54.TabStop = false;
            this.box54.Tag = "3";
            this.box54.Click += new System.EventHandler(this.playPiece);
            this.box54.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box54.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box53
            // 
            this.box53.Location = new System.Drawing.Point(324, 530);
            this.box53.Name = "box53";
            this.box53.Size = new System.Drawing.Size(124, 111);
            this.box53.TabIndex = 41;
            this.box53.TabStop = false;
            this.box53.Tag = "2";
            this.box53.Click += new System.EventHandler(this.playPiece);
            this.box53.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box53.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box52
            // 
            this.box52.Location = new System.Drawing.Point(200, 530);
            this.box52.Name = "box52";
            this.box52.Size = new System.Drawing.Size(124, 111);
            this.box52.TabIndex = 40;
            this.box52.TabStop = false;
            this.box52.Tag = "1";
            this.box52.Click += new System.EventHandler(this.playPiece);
            this.box52.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box52.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box51
            // 
            this.box51.Location = new System.Drawing.Point(76, 530);
            this.box51.Name = "box51";
            this.box51.Size = new System.Drawing.Size(124, 111);
            this.box51.TabIndex = 39;
            this.box51.TabStop = false;
            this.box51.Tag = "0";
            this.box51.Click += new System.EventHandler(this.playPiece);
            this.box51.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box51.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box46
            // 
            this.box46.Location = new System.Drawing.Point(696, 419);
            this.box46.Name = "box46";
            this.box46.Size = new System.Drawing.Size(124, 111);
            this.box46.TabIndex = 37;
            this.box46.TabStop = false;
            this.box46.Tag = "5";
            this.box46.Click += new System.EventHandler(this.playPiece);
            this.box46.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box46.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box45
            // 
            this.box45.Location = new System.Drawing.Point(572, 419);
            this.box45.Name = "box45";
            this.box45.Size = new System.Drawing.Size(124, 111);
            this.box45.TabIndex = 35;
            this.box45.TabStop = false;
            this.box45.Tag = "4";
            this.box45.Click += new System.EventHandler(this.playPiece);
            this.box45.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box45.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box47
            // 
            this.box47.Location = new System.Drawing.Point(820, 419);
            this.box47.Name = "box47";
            this.box47.Size = new System.Drawing.Size(124, 111);
            this.box47.TabIndex = 36;
            this.box47.TabStop = false;
            this.box47.Tag = "6";
            this.box47.Click += new System.EventHandler(this.playPiece);
            this.box47.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box47.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box44
            // 
            this.box44.Location = new System.Drawing.Point(448, 419);
            this.box44.Name = "box44";
            this.box44.Size = new System.Drawing.Size(124, 111);
            this.box44.TabIndex = 34;
            this.box44.TabStop = false;
            this.box44.Tag = "3";
            this.box44.Click += new System.EventHandler(this.playPiece);
            this.box44.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box44.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box43
            // 
            this.box43.Location = new System.Drawing.Point(324, 419);
            this.box43.Name = "box43";
            this.box43.Size = new System.Drawing.Size(124, 111);
            this.box43.TabIndex = 33;
            this.box43.TabStop = false;
            this.box43.Tag = "2";
            this.box43.Click += new System.EventHandler(this.playPiece);
            this.box43.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box43.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box42
            // 
            this.box42.Location = new System.Drawing.Point(200, 419);
            this.box42.Name = "box42";
            this.box42.Size = new System.Drawing.Size(124, 111);
            this.box42.TabIndex = 32;
            this.box42.TabStop = false;
            this.box42.Tag = "1";
            this.box42.Click += new System.EventHandler(this.playPiece);
            this.box42.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box42.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box41
            // 
            this.box41.Location = new System.Drawing.Point(76, 419);
            this.box41.Name = "box41";
            this.box41.Size = new System.Drawing.Size(124, 111);
            this.box41.TabIndex = 31;
            this.box41.TabStop = false;
            this.box41.Tag = "0";
            this.box41.Click += new System.EventHandler(this.playPiece);
            this.box41.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box41.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box36
            // 
            this.box36.Location = new System.Drawing.Point(696, 308);
            this.box36.Name = "box36";
            this.box36.Size = new System.Drawing.Size(124, 111);
            this.box36.TabIndex = 29;
            this.box36.TabStop = false;
            this.box36.Tag = "5";
            this.box36.Click += new System.EventHandler(this.playPiece);
            this.box36.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box36.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box35
            // 
            this.box35.Location = new System.Drawing.Point(572, 308);
            this.box35.Name = "box35";
            this.box35.Size = new System.Drawing.Size(124, 111);
            this.box35.TabIndex = 27;
            this.box35.TabStop = false;
            this.box35.Tag = "4";
            this.box35.Click += new System.EventHandler(this.playPiece);
            this.box35.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box35.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box37
            // 
            this.box37.Location = new System.Drawing.Point(820, 308);
            this.box37.Name = "box37";
            this.box37.Size = new System.Drawing.Size(124, 111);
            this.box37.TabIndex = 28;
            this.box37.TabStop = false;
            this.box37.Tag = "6";
            this.box37.Click += new System.EventHandler(this.playPiece);
            this.box37.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box37.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box34
            // 
            this.box34.Location = new System.Drawing.Point(448, 308);
            this.box34.Name = "box34";
            this.box34.Size = new System.Drawing.Size(124, 111);
            this.box34.TabIndex = 26;
            this.box34.TabStop = false;
            this.box34.Tag = "3";
            this.box34.Click += new System.EventHandler(this.playPiece);
            this.box34.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box34.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box33
            // 
            this.box33.Location = new System.Drawing.Point(324, 308);
            this.box33.Name = "box33";
            this.box33.Size = new System.Drawing.Size(124, 111);
            this.box33.TabIndex = 25;
            this.box33.TabStop = false;
            this.box33.Tag = "2";
            this.box33.Click += new System.EventHandler(this.playPiece);
            this.box33.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box33.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box32
            // 
            this.box32.Location = new System.Drawing.Point(200, 308);
            this.box32.Name = "box32";
            this.box32.Size = new System.Drawing.Size(124, 111);
            this.box32.TabIndex = 24;
            this.box32.TabStop = false;
            this.box32.Tag = "1";
            this.box32.Click += new System.EventHandler(this.playPiece);
            this.box32.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box32.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box31
            // 
            this.box31.Location = new System.Drawing.Point(76, 308);
            this.box31.Name = "box31";
            this.box31.Size = new System.Drawing.Size(124, 111);
            this.box31.TabIndex = 23;
            this.box31.TabStop = false;
            this.box31.Tag = "0";
            this.box31.Click += new System.EventHandler(this.playPiece);
            this.box31.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box31.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box26
            // 
            this.box26.Location = new System.Drawing.Point(696, 197);
            this.box26.Name = "box26";
            this.box26.Size = new System.Drawing.Size(124, 111);
            this.box26.TabIndex = 21;
            this.box26.TabStop = false;
            this.box26.Tag = "5";
            this.box26.Click += new System.EventHandler(this.playPiece);
            this.box26.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box26.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box25
            // 
            this.box25.Location = new System.Drawing.Point(572, 197);
            this.box25.Name = "box25";
            this.box25.Size = new System.Drawing.Size(124, 111);
            this.box25.TabIndex = 19;
            this.box25.TabStop = false;
            this.box25.Tag = "4";
            this.box25.Click += new System.EventHandler(this.playPiece);
            this.box25.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box25.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box27
            // 
            this.box27.Location = new System.Drawing.Point(820, 197);
            this.box27.Name = "box27";
            this.box27.Size = new System.Drawing.Size(124, 111);
            this.box27.TabIndex = 20;
            this.box27.TabStop = false;
            this.box27.Tag = "6";
            this.box27.Click += new System.EventHandler(this.playPiece);
            this.box27.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box27.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box24
            // 
            this.box24.Location = new System.Drawing.Point(448, 197);
            this.box24.Name = "box24";
            this.box24.Size = new System.Drawing.Size(124, 111);
            this.box24.TabIndex = 18;
            this.box24.TabStop = false;
            this.box24.Tag = "3";
            this.box24.Click += new System.EventHandler(this.playPiece);
            this.box24.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box24.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box23
            // 
            this.box23.Location = new System.Drawing.Point(324, 197);
            this.box23.Name = "box23";
            this.box23.Size = new System.Drawing.Size(124, 111);
            this.box23.TabIndex = 17;
            this.box23.TabStop = false;
            this.box23.Tag = "2";
            this.box23.Click += new System.EventHandler(this.playPiece);
            this.box23.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box23.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box22
            // 
            this.box22.Location = new System.Drawing.Point(200, 197);
            this.box22.Name = "box22";
            this.box22.Size = new System.Drawing.Size(124, 111);
            this.box22.TabIndex = 16;
            this.box22.TabStop = false;
            this.box22.Tag = "1";
            this.box22.Click += new System.EventHandler(this.playPiece);
            this.box22.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box22.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box21
            // 
            this.box21.Location = new System.Drawing.Point(76, 197);
            this.box21.Name = "box21";
            this.box21.Size = new System.Drawing.Size(124, 111);
            this.box21.TabIndex = 15;
            this.box21.TabStop = false;
            this.box21.Tag = "0";
            this.box21.Click += new System.EventHandler(this.playPiece);
            this.box21.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box21.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box16
            // 
            this.box16.Location = new System.Drawing.Point(696, 86);
            this.box16.Name = "box16";
            this.box16.Size = new System.Drawing.Size(124, 111);
            this.box16.TabIndex = 13;
            this.box16.TabStop = false;
            this.box16.Tag = "5";
            this.box16.Click += new System.EventHandler(this.playPiece);
            this.box16.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box16.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box15
            // 
            this.box15.Location = new System.Drawing.Point(572, 86);
            this.box15.Name = "box15";
            this.box15.Size = new System.Drawing.Size(124, 111);
            this.box15.TabIndex = 12;
            this.box15.TabStop = false;
            this.box15.Tag = "4";
            this.box15.Click += new System.EventHandler(this.playPiece);
            this.box15.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box15.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box17
            // 
            this.box17.Location = new System.Drawing.Point(820, 86);
            this.box17.Name = "box17";
            this.box17.Size = new System.Drawing.Size(124, 111);
            this.box17.TabIndex = 12;
            this.box17.TabStop = false;
            this.box17.Tag = "6";
            this.box17.Click += new System.EventHandler(this.playPiece);
            this.box17.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box17.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box14
            // 
            this.box14.Location = new System.Drawing.Point(448, 86);
            this.box14.Name = "box14";
            this.box14.Size = new System.Drawing.Size(124, 111);
            this.box14.TabIndex = 11;
            this.box14.TabStop = false;
            this.box14.Tag = "3";
            this.box14.Click += new System.EventHandler(this.playPiece);
            this.box14.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box14.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box13
            // 
            this.box13.InitialImage = global::ConnectFour_Group3.Properties.Resources.Blank_space;
            this.box13.Location = new System.Drawing.Point(324, 86);
            this.box13.Name = "box13";
            this.box13.Size = new System.Drawing.Size(124, 111);
            this.box13.TabIndex = 10;
            this.box13.TabStop = false;
            this.box13.Tag = "2";
            this.box13.Click += new System.EventHandler(this.playPiece);
            this.box13.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box13.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box12
            // 
            this.box12.InitialImage = global::ConnectFour_Group3.Properties.Resources.Blank_space;
            this.box12.Location = new System.Drawing.Point(200, 86);
            this.box12.Name = "box12";
            this.box12.Size = new System.Drawing.Size(124, 111);
            this.box12.TabIndex = 9;
            this.box12.TabStop = false;
            this.box12.Tag = "1";
            this.box12.Click += new System.EventHandler(this.playPiece);
            this.box12.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box12.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // box11
            // 
            this.box11.InitialImage = global::ConnectFour_Group3.Properties.Resources.Blank_space;
            this.box11.Location = new System.Drawing.Point(76, 86);
            this.box11.Name = "box11";
            this.box11.Size = new System.Drawing.Size(124, 111);
            this.box11.TabIndex = 8;
            this.box11.TabStop = false;
            this.box11.Tag = "0";
            this.box11.Click += new System.EventHandler(this.playPiece);
            this.box11.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.box11.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ConnectFour_Group3.Properties.Resources.red_side_design_1;
            this.pictureBox2.Location = new System.Drawing.Point(950, -23);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 822);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 57;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ConnectFour_Group3.Properties.Resources.blue_side_design_1;
            this.pictureBox1.Location = new System.Drawing.Point(-4, -39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 838);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 58;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 768);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lblTurnDisp);
            this.Controls.Add(this.box66);
            this.Controls.Add(this.box65);
            this.Controls.Add(this.box67);
            this.Controls.Add(this.box64);
            this.Controls.Add(this.box63);
            this.Controls.Add(this.box62);
            this.Controls.Add(this.box61);
            this.Controls.Add(this.box56);
            this.Controls.Add(this.box55);
            this.Controls.Add(this.box57);
            this.Controls.Add(this.box54);
            this.Controls.Add(this.box53);
            this.Controls.Add(this.box52);
            this.Controls.Add(this.box51);
            this.Controls.Add(this.box46);
            this.Controls.Add(this.box45);
            this.Controls.Add(this.box47);
            this.Controls.Add(this.box44);
            this.Controls.Add(this.box43);
            this.Controls.Add(this.box42);
            this.Controls.Add(this.box41);
            this.Controls.Add(this.box36);
            this.Controls.Add(this.box35);
            this.Controls.Add(this.box37);
            this.Controls.Add(this.box34);
            this.Controls.Add(this.box33);
            this.Controls.Add(this.box32);
            this.Controls.Add(this.box31);
            this.Controls.Add(this.box26);
            this.Controls.Add(this.box25);
            this.Controls.Add(this.box27);
            this.Controls.Add(this.box24);
            this.Controls.Add(this.box23);
            this.Controls.Add(this.box22);
            this.Controls.Add(this.box21);
            this.Controls.Add(this.box16);
            this.Controls.Add(this.box15);
            this.Controls.Add(this.box17);
            this.Controls.Add(this.box14);
            this.Controls.Add(this.box13);
            this.Controls.Add(this.box12);
            this.Controls.Add(this.box11);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.box66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.box11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox box11;
        private System.Windows.Forms.PictureBox box12;
        private System.Windows.Forms.PictureBox box13;
        private System.Windows.Forms.PictureBox box14;
        private System.Windows.Forms.PictureBox box17;
        private System.Windows.Forms.PictureBox box15;
        private System.Windows.Forms.PictureBox box16;
        private System.Windows.Forms.PictureBox box26;
        private System.Windows.Forms.PictureBox box25;
        private System.Windows.Forms.PictureBox box27;
        private System.Windows.Forms.PictureBox box24;
        private System.Windows.Forms.PictureBox box23;
        private System.Windows.Forms.PictureBox box22;
        private System.Windows.Forms.PictureBox box21;
        private System.Windows.Forms.PictureBox box36;
        private System.Windows.Forms.PictureBox box35;
        private System.Windows.Forms.PictureBox box37;
        private System.Windows.Forms.PictureBox box34;
        private System.Windows.Forms.PictureBox box33;
        private System.Windows.Forms.PictureBox box32;
        private System.Windows.Forms.PictureBox box31;
        private System.Windows.Forms.PictureBox box46;
        private System.Windows.Forms.PictureBox box45;
        private System.Windows.Forms.PictureBox box47;
        private System.Windows.Forms.PictureBox box44;
        private System.Windows.Forms.PictureBox box43;
        private System.Windows.Forms.PictureBox box42;
        private System.Windows.Forms.PictureBox box41;
        private System.Windows.Forms.PictureBox box56;
        private System.Windows.Forms.PictureBox box55;
        private System.Windows.Forms.PictureBox box57;
        private System.Windows.Forms.PictureBox box54;
        private System.Windows.Forms.PictureBox box53;
        private System.Windows.Forms.PictureBox box52;
        private System.Windows.Forms.PictureBox box51;
        private System.Windows.Forms.PictureBox box66;
        private System.Windows.Forms.PictureBox box65;
        private System.Windows.Forms.PictureBox box67;
        private System.Windows.Forms.PictureBox box64;
        private System.Windows.Forms.PictureBox box63;
        private System.Windows.Forms.PictureBox box62;
        private System.Windows.Forms.PictureBox box61;
        private System.Windows.Forms.Label lblTurnDisp;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

